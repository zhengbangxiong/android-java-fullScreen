const e=""+new URL("check-green-success-b3dbd4e8.svg",import.meta.url).href;export{e as c};

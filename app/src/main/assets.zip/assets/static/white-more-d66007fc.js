const e=""+new URL("white-more-eb76ba1f.svg",import.meta.url).href;export{e as _};

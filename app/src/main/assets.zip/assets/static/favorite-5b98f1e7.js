const e=""+new URL("favorite-a63277f1.svg",import.meta.url).href;export{e as f};

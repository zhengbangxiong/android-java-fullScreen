const e=""+new URL("default-user-77626008.svg",import.meta.url).href;export{e as d};

const r=""+new URL("pure-arrow-left-fb22b7b4.svg",import.meta.url).href,e=""+new URL("square-arrow-user-left-b48bcdef.svg",import.meta.url).href;export{r as p,e as s};

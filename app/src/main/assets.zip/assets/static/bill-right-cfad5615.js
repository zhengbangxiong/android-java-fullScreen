const t=""+new URL("bill-right-2bbf3c7d.svg",import.meta.url).href;export{t as b};

const s=""+new URL("small-bsc-0a41a2e1.svg",import.meta.url).href;export{s};

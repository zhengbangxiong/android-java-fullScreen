const a=""+new URL("small-solana-37a60bea.svg",import.meta.url).href;export{a as _};

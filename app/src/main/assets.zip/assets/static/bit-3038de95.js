const t=""+new URL("bit-5c3046fe.svg",import.meta.url).href;export{t as _};

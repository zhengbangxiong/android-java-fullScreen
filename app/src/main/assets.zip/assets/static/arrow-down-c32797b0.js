const r=""+new URL("arrow-down-853d645a.svg",import.meta.url).href;export{r as d};

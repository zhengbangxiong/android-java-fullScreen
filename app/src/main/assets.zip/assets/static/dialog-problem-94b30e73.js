const o=""+new URL("dialog-problem-250a1d12.svg",import.meta.url).href;export{o as d};

const r=""+new URL("dialog-error-0b5a5cd3.svg",import.meta.url).href;export{r as d};

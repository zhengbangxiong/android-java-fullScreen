const e=""+new URL("red-down-5d55dfe8.svg",import.meta.url).href,r=""+new URL("green-up-1bc3f68e.svg",import.meta.url).href;export{r as g,e as r};

import{_ as s}from"./BackNav-ac689118.js";import{d as c,z as l,u as p,o as d,a as h,w as u,b as o,x as m,e,ap as y,_ as f}from"./index-6acfcdbc.js";import"./square-arrow-user-left-da445397.js";import"./square-arrow-left-a5246e60.js";const g=`<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Privacy Policy - TradingBase</title>
<style>
  body {
    font-family: Arial, Helvetica, sans-serif;
    line-height: 1.6;
    padding: 0px 16px 20px;
    max-width: 900px;
    margin: auto;
  }
  h1, h2, h3, h4 {
    font-weight: bold;
    margin-top: 24px;
  }
  ul {
    /* padding-left: 16px; */
  }
  p {
    margin: 14px 0;
  }
</style>
</head>
<body>

<div style="font-size: 26px; text-align: center; font-weight: 500;">Privacy Policy</div>

<p>Please read the "Privacy Policy" carefully and make sure you understand our rules for handling your personal information. During the reading process, if you have any questions, you can give us feedback at any time. If you do not agree to any terms in the agreement, you should stop accessing TradingBase immediately.</p>

<p>The following is the text of TradingBase's "Privacy Policy":</p>

<p>In order to effectively protect the privacy rights of TradingBase users and optimize the user experience, the TradingBase operator (hereinafter referred to as "we") has formulated this privacy policy in accordance with current regulations and policies. This privacy policy will detail the policies and measures of TradingBase operators in obtaining, managing, and protecting users' personal information. This privacy policy applies to all services provided to you by TradingBase operators, regardless of whether you obtain TradingBase services through computer equipment, mobile terminals, or other equipment.</p>

<p>If you have any questions about this privacy policy or related matters, you can contact us at any time by visiting the TradingBase online feedback system, TradingBase official service account, and other methods. We have formulated this "Privacy Policy" and especially reminded: The terms of this privacy policy are the basic documents for your use of TradingBase services and various functions. We hope that you read carefully before using TradingBase services and make it clear that you have fully understood and accepted the terms of this policy. We hope you can make a suitable choice based on your own understanding.</p>

<p>The terms of this privacy policy will help you understand the following:</p>

<ul>
  <li><strong>The personal information involved in this privacy policy includes:</strong>
    <ul>
      <li>Basic information (including personal name, avatar profile photo, birthday, gender, address/personal location information; network identification information (including system account number, IP address, email address, and related passwords);</li>
      <li>Personal Internet records (including search records, software usage records, and click records);</li>
      <li>Personal common device information (including hardware model, device MAC address, operating system type, software list, unique device identification codes such as IMEI/android ID/IDFA/OPENUDID/GUID, SIM card IMSI information, etc.)</li>
    </ul>
  </li>
  <li><strong>Personal sensitive information includes:</strong>
    <ul>
      <li>Network identification information (including account name, nickname, email, password, Photo album, and security questions and answers);</li>
      <li>Other information (including address book, itinerary information, browsing history, precise location information, etc.);</li>
      <li>Relevant identification information.</li>
    </ul>
  </li>
</ul>

<p>We will collect and use your information in accordance with the privacy policy, but we will not collect personal information in a mandatory binding manner just because of your agreement to this privacy policy.</p>

<p>When you use or turn on relevant functions or use services, we will collect and use relevant information in order to realize the functions and services necessary. Unless it is necessary to achieve basic business functions or in accordance with the requirements of laws and regulations, you can refuse to provide without affecting other functions or services. We will explain what is necessary information item by item in the privacy policy.</p>

<p>If you are not logged in to your account, we will use the identifier information corresponding to the device to ensure the basic functions of the information push. If you log in to your account, we will push information based on the account information.</p>

<p>TradingBase may call some of your device permissions. These permissions will not be turned on by default. They will only be used to implement specific functions or services with your express authorization. You can also withdraw authorization by turning off the corresponding business functions.</p>

<p>This privacy policy applies to your access and use of our products and services through the TradingBase application, TradingBase webpage, TradingBase software development kit (SDK), and application programming interface (API).</p>

<hr />

<h2>1 How Do We Collect and Use Your Information?</h2>

<h3>1.1 Register and log in</h3>
<p>When you register or log in to TradingBase, we collect your nickname, email, password, etc., to help you create and manage your account.</p>

<h3>1.2 Search</h3>
<p>When you use the search service, we collect your search keywords and logs. Some are temporarily stored locally to optimize your experience.</p>

<h3>1.3 Improve our products and services</h3>
<p>We use collected information for analysis, product optimization, and statistical reports that do not contain personal identification information.</p>

<h3>1.4 Safe operation</h3>
<p>To ensure system security, we collect device information, IP, system logs, installation list, process info, crash data, etc. to detect risks and prevent fraud.</p>

<h3>1.5 Changes to the purpose of collecting personal information</h3>
<p>When new features require new personal information, we will inform you in advance and obtain consent.</p>

<hr />

<h2>2 How we use cookies and similar technologies</h2>

<h3>2.1 Ensure safe and efficient operation</h3>
<p>Cookies are used for authentication and improving login/security.</p>

<h3>2.2 Provide a better access experience</h3>
<p>Cookies help avoid repeated filling of data and store search history.</p>

<h3>2.3 Recommend and display content</h3>
<p>We use cookies to understand habits and recommend relevant content.</p>

<h3>2.4 Clearing cookies</h3>
<p>Clearing cookies may cause some features to be unusable.</p>

<hr />

<h2>3 How do we share, transfer, and disclose personal information</h2>

<h3>3.1 Sharing</h3>
<p>We share information only with your consent or when anonymized.</p>

<h3>3.2 Assignment</h3>
<p>In business transfers (merger, acquisition), personal data may be transferred under protection.</p>

<h3>3.3 Disclosure</h3>
<p>We do not publicly disclose information unless required by law.</p>

<hr />

<h2>4 How we store and protect personal information</h2>

<h3>4.1 Storage location</h3>
<p>We store your information securely using encryption and access control.</p>

<h3>4.2 Storage method</h3>
<p>Information is stored in local cache, server databases, and logs.</p>

<h3>4.3 Storage period</h3>
<p>We retain personal information for the required duration by law, usually not less than 6 months.</p>

<hr />

<h2>5 Manage your personal information</h2>

<p>We follow strict data management processes, including encryption, identity verification, access control, employee training, and emergency procedures for data breaches.</p>

<p>Once you leave TradingBase and use other websites or services, we no longer control or protect your personal information.</p>

</body>
</html>
`,v=`<!DOCTYPE html>
<html lang="zh-Hant">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>隱私權政策 - TradingBase</title>
    <style>
      body {
        font-family: Arial, Helvetica, sans-serif;
        line-height: 1.6;
        padding: 0px 16px 20px;
        max-width: 900px;
        margin: auto;
      }
      h1,
      h2,
      h3,
      h4 {
        font-weight: bold;
        margin-top: 24px;
      }
      ul {
        /* padding-left: 16px; */
      }
      p {
        margin: 14px 0;
      }
    </style>
  </head>
  <body>
    <div style="font-size: 26px; text-align: center; font-weight: 500">
      隱私權政策
    </div>

    <p>
      請仔細閱讀本《隱私權政策》，並確保您理解我們處理您的個人資訊的相關規則。在閱讀過程中，如您有任何疑問，可隨時向我們反饋。若您不同意本協議中的任何條款，您應立即停止訪問
      TradingBase。
    </p>

    <p>以下為 TradingBase《隱私權政策》正文：</p>

    <p>
      為了有效保護 TradingBase 使用者的隱私權並提升使用者體驗，TradingBase
      的運營方（以下稱「我們」）依據現行法律法規制定了本隱私權政策。本政策將詳細說明
      TradingBase
      在取得、管理及保護使用者個人資訊方面的政策與措施。本隱私權政策適用於您透過電腦設備、行動裝置或其他方式取得
      TradingBase 所提供的所有服務。
    </p>

    <p>
      如您對本隱私權政策或相關事宜有任何疑問，可隨時透過 TradingBase
      線上反饋系統、TradingBase
      官方服務帳號等方式與我們聯繫。我們特別提醒您：本隱私權政策的條款是您使用
      TradingBase 服務及各項功能的基礎性文件。我們希望您在使用 TradingBase
      服務前仔細閱讀，並確認您已充分理解並接受本政策條款，並能根據您的理解做出適合您的選擇。
    </p>

    <p>本隱私權政策的條款將幫助您了解以下內容：</p>

    <ul>
      <li>
        <strong>本隱私權政策涉及的個人資訊包括：</strong>
        <ul>
          <li>
            基本資訊（包括個人姓名、頭像照片、生日、性別、地址／個人位置資訊；網路識別資訊（包括系統帳號、IP
            位址、電子郵件地址及相關密碼）；
          </li>
          <li>個人網路記錄（包括搜尋記錄、軟體使用記錄、點擊記錄）；</li>
          <li>
            常用個人設備資訊（包括硬體型號、設備 MAC
            位址、作業系統類型、軟體清單、裝置識別碼如 IMEI/android
            ID/IDFA/OPENUDID/GUID、SIM 卡 IMSI 資訊等）。
          </li>
        </ul>
      </li>
      <li>
        <strong>個人敏感資訊包括：</strong>
        <ul>
          <li>
            網路識別資訊（包括帳號名稱、暱稱、電子郵件、密碼、相簿、密保問題及答案）；
          </li>
          <li>其他資訊（包括通訊錄、行程資訊、瀏覽記錄、精確位置資訊等）；</li>
          <li>相關身份識別資訊。</li>
        </ul>
      </li>
    </ul>

    <p>
      我們將依據本隱私權政策收集與使用您的資訊，但不會因您同意本政策而強制收集不必要的個人資訊。
    </p>

    <p>
      當您使用或啟動相關功能或服務時，為實現必要功能，我們才會收集並使用相關資訊。除非屬於實現基本業務功能或符合法律規定所必需，您可以選擇拒絕提供，不會影響其他功能使用。我們會在本政策中逐項說明哪些是必要的資訊。
    </p>

    <p>
      若您未登入帳號，我們會使用裝置識別資訊以確保基本推播功能正常運作；若您已登入帳號，我們則會基於帳號資訊提供推播。
    </p>

    <p>
      TradingBase
      可能會調用您裝置的部分權限。這些權限預設不會開啟，僅會在您明確授權後用於提供特定功能。您亦可隨時透過關閉相關功能來撤回授權。
    </p>

    <p>
      本隱私權政策適用於您透過 TradingBase App、TradingBase 網頁、TradingBase
      開發套件（SDK）、應用程式介面（API）取得與使用我們的產品與服務。
    </p>

    <hr />

    <h2>1 我們如何收集與使用您的資訊？</h2>

    <h3>1.1 註冊與登入</h3>
    <p>
      當您註冊或登入 TradingBase
      時，我們會收集您的暱稱、電子郵件、密碼等資訊，用以協助您建立並管理帳號。
    </p>

    <h3>1.2 搜尋</h3>
    <p>
      當您使用搜尋服務時，我們會收集您的搜尋關鍵字及相關紀錄。其中部分可能會暫存在本機，以提升您的使用體驗。
    </p>

    <h3>1.3 改善產品與服務</h3>
    <p>
      我們會使用收集的資訊進行分析、產品優化與統計報告，該報告不含個人身份識別資訊。
    </p>

    <h3>1.4 安全運行</h3>
    <p>
      為確保系統安全，我們會收集設備資訊、IP、系統日誌、安裝清單、程序資訊、崩潰資料等，用於風險偵測及防詐騙。
    </p>

    <h3>1.5 個人資訊收集目的變更</h3>
    <p>若新功能需要新的個人資訊，我們會提前告知並取得您的同意。</p>

    <hr />

    <h2>2 我們如何使用 Cookie 及類似技術</h2>

    <h3>2.1 確保安全並高效運行</h3>
    <p>Cookies 用於身分驗證及提升登入／安全性。</p>

    <h3>2.2 提供更佳的使用體驗</h3>
    <p>Cookies 可協助避免重複填寫資料，並保存搜尋記錄。</p>

    <h3>2.3 推薦與展示內容</h3>
    <p>我們使用 Cookies 了解您的使用習慣，以推薦相關內容。</p>

    <h3>2.4 清除 Cookies</h3>
    <p>清除 Cookies 可能導致部分功能無法正常使用。</p>

    <hr />

    <h2>3 我們如何共享、轉移與公開個人資訊</h2>

    <h3>3.1 共享</h3>
    <p>我們僅在您同意或資訊已匿名化的情況下共享您的資訊。</p>

    <h3>3.2 轉移</h3>
    <p>在企業併購、重組、收購等情況下，您的資訊可能在受保護的前提下被轉移。</p>

    <h3>3.3 公開披露</h3>
    <p>除法律要求外，我們不會公開披露您的個人資訊。</p>

    <hr />

    <h2>4 我們如何儲存與保護個人資訊</h2>

    <h3>4.1 儲存位置</h3>
    <p>我們以加密及權限控制方式安全儲存您的資訊。</p>

    <h3>4.2 儲存方式</h3>
    <p>資訊可能儲存在本地快取、伺服器資料庫與系統日誌中。</p>

    <h3>4.3 儲存期限</h3>
    <p>根據法律要求，我們會保留您的個人資訊，通常不低於 6 個月。</p>

    <hr />

    <h2>5 管理您的個人資訊</h2>

    <p>
      我們遵循嚴格的資料管理流程，包括加密、身分驗證、權限管理、員工培訓與數據外洩應急處理等。
    </p>

    <p>
      當您離開 TradingBase
      並使用其他網站或服務時，我們不再控制或保護您的個人資訊。
    </p>
  </body>
</html>
`,w={class:"privacyPolicy"},b=["innerHTML"],T=c({__name:"privacyPolicy",setup(B){const n=l(),{locale:a}=p(),t=()=>{n.options.history.state.back?n.back():n.push({name:"HomeTotal"})};return(k,i)=>{const r=s;return d(),h(y,{name:"slide-left",back_name:"slide-right"},{default:u(()=>[o("div",w,[m(r,{onGoBack:i[0]||(i[0]=I=>t()),backTitle:" "}),o("div",{innerHTML:e(a)=="EN"?e(g):e(v)},null,8,b)])]),_:1})}}});const W=f(T,[["__scopeId","data-v-086c4cc2"]]);export{W as default};

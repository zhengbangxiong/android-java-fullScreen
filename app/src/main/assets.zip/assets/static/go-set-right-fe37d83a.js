const t=""+new URL("go-set-right-5da267e9.svg",import.meta.url).href;export{t as g};

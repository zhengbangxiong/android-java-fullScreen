const s=""+new URL("dialog-success-4971fc4d.svg",import.meta.url).href;export{s as d};

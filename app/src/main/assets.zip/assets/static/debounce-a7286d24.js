function u(t,i){let e=null;return function(...n){e&&clearTimeout(e),e=setTimeout(()=>{t.apply(this,n)},i)}}export{u as d};

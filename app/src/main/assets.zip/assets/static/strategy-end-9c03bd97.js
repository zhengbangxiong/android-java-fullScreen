const r=""+new URL("strategy-end-6c7632b6.svg",import.meta.url).href;export{r as d};

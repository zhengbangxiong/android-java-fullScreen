const e=""+new URL("profile-edit-a206929d.svg",import.meta.url).href;export{e as d};

const a=""+new URL("small-eth-5a81a0f4.svg",import.meta.url).href;export{a as s};

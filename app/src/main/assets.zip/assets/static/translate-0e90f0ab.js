const t=""+new URL("translate-f3290952.svg",import.meta.url).href;export{t as _};

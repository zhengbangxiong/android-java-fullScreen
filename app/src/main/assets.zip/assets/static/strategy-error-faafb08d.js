const r=""+new URL("strategy-error-0990874c.svg",import.meta.url).href;export{r as s};

const r=""+new URL("clear-6c073002.svg",import.meta.url).href;export{r as _};

const e=""+new URL("full-eye-49a3f031.svg",import.meta.url).href;export{e as _};

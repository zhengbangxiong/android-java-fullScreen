const e=""+new URL("pay-no-select-48b81d25.svg",import.meta.url).href,t=""+new URL("pay-select-7550b425.svg",import.meta.url).href;export{e as a,t as p};

const s=""+new URL("full-circle-success-780a2072.svg",import.meta.url).href;export{s as _};

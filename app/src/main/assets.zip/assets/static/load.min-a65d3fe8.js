const T=document.getElementsByTagName("head")[0],p=1e4,y=`<div id="tac-loading" style="
    border: 1px solid #eee;
    /* background-color: #409EFF; */
    border-radius: 5px;
    width: 318px;
    height: 318px;
    line-height: 318px;
    color: #606266;
    text-align: center;
    position: relative;
    box-sizing: border-box;
"></div>`;function w(t){var r=document.querySelector(t);r&&(r.innerHTML=y)}function u(t){let r=document.querySelector(t);r&&(r.innerHTML="")}function m(t,r,i,l,n){const e=t.scriptUrls,c=t.cssUrls,d=t.timeout||p;let s=e.length+c.length;function a(o,g){if(s--,o&&s===0){if(u(r.bindEl),!window.TAC)throw new Error("TAC");l(new TAC(r,i))}else o||(u(r.bindEl),n(g))}setTimeout(()=>{s!==0&&w(r.bindEl)},10),e.forEach(function(o){f(typeof o=="string"?{url:o}:o,a,"script",d)}),c.forEach(function(o){f(typeof o=="string"?{url:o}:o,a,"link",d)})}function f(t,r,i="script",l){if(document.querySelector(`${i}[${i==="script"?"src":"href"}="${t.url}"]`))return void r(!0,t);let n=!1;const e=document.createElement(i);i==="link"?e.rel="stylesheet":e.async=!0,e[i==="script"?"src":"href"]=t.url;let c;e.onload=e.onreadystatechange=()=>{n||e.readyState&&e.readyState!=="loaded"&&e.readyState!=="complete"||function d(s){t.checkOnReady?c=setTimeout(()=>{t.checkOnReady()?s():d(s)},10):s()}(()=>{n=!0,setTimeout(()=>r(n,t),0)})},e.onerror=()=>{r(n=!1,t)},T.appendChild(e),setTimeout(()=>{n||(c&&clearTimeout(c),e.onload=e.onerror=null,e.remove&&e.remove(),r(n,t))},l||p)}function h(t,r,i){return new Promise((l,n)=>{let e={...typeof t=="string"?{url:t}:t};e.url&&(e.url.endsWith("/")||(e.url+="/"),e.scriptUrls||(e.scriptUrls=[e.url+"js/tac.min.js"]),e.cssUrls||(e.cssUrls=[e.url+"css/tac.css"])),e.scriptUrls&&e.cssUrls?m(e,r,i,l,n):n("")})}setTimeout(()=>{let t=document.scripts;for(let r=0;r<t.length;r++)if(t[r].src.indexOf("load.js")>1||t[r].src.indexOf("load.min.js")>1){t[r].src.substring(t[r].src.indexOf("/"),t[r].src.lastIndexOf("/"));break}},100),window.loadCaptchaScript=m,window.loadTAC=h,window.initTAC=h;

const e=""+new URL("search-3848ea8f.svg",import.meta.url).href;export{e as _};

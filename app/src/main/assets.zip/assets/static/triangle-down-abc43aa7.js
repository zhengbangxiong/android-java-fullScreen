const o=""+new URL("economy_img-90da304d.svg",import.meta.url).href;export{o as _};

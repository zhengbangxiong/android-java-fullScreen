import{l as e,f as o,c as a}from"./index-e6988d2a.js";import{d as c}from"./base-6f47fc9f.js";const r=c([String,Object,Function]),s={validating:e,success:o,error:a};export{s as V,r as i};

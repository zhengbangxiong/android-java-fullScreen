const e=""+new URL("arrow-up-2cb9e587.svg",import.meta.url).href;export{e as g};

const r=""+new URL("square-arrow-left-293803e9.svg",import.meta.url).href;export{r as s};

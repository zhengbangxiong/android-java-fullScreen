const e=""+new URL("indexView_left_circle-d990470c.svg",import.meta.url).href,r=""+new URL("indexView_right_circle-f801e88f.svg",import.meta.url).href;export{e as _,r as a};

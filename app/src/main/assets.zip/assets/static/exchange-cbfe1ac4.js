const e=""+new URL("exchange-c38fa7ba.svg",import.meta.url).href;export{e as _};

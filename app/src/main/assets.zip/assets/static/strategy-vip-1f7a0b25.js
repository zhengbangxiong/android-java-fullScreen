const t=""+new URL("strategy-vip-30295cbd.svg",import.meta.url).href;export{t as s};

const o=""+new URL("person-copy-8dd2f9a8.svg",import.meta.url).href;export{o as p};

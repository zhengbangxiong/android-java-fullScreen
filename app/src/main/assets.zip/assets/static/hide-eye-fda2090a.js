const e=""+new URL("show-eye-844af160.svg",import.meta.url).href,o=""+new URL("hide-eye-c0f5b0aa.svg",import.meta.url).href;export{o as h,e as s};
